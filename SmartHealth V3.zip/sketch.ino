#include <Wire.h>
#include <LiquidCrystal_I2C.h>
LiquidCrystal_I2C lcd(0x27,20,4);
const int A=32,B=33,CONS=25,L1=18,L2=19;
const int VERDE=26,AMARELO=27,VERMELHO=14;
const int REF=3;
unsigned long presentes=0, entradas=0, saidas=0, pico=0;
const unsigned long LIMITE=5000;
int primeiro=0; unsigned long inicio=0;
bool anteriorA=false, anteriorB=false, bloqueio=false;
int ultimoEstado=-1;
void linha(int n, String s){
  s=s.substring(0,20); while(s.length()<20) s+=' ';
  lcd.setCursor(0,n); lcd.print(s);
}
void painel(bool consultorio,int leitos){
  bool alerta=presentes>=REF && (!consultorio || leitos<2);
  digitalWrite(VERDE,presentes<2);
  digitalWrite(AMARELO,presentes==2);
  digitalWrite(VERMELHO,presentes>=REF);
  linha(0,String("Espera: ")+presentes+"/"+REF);
  linha(1,String("Consult: ")+(consultorio?"OCUPADO":"VAZIO"));
  linha(2,String("Leitos ocup: ")+leitos+"/2");
  linha(3,alerta?"VERIFICAR GARGALO":presentes>=REF?"LOTACAO ALTA": "Monitoramento ativo");
  Serial.printf("{\"espera\":%lu,\"entradas\":%lu,\"saidas\":%lu,\"pico\":%lu,\"consultorio_ocupado\":%s,\"leitos_ocupados\":%d,\"alerta\":%s}\n",presentes,entradas,saidas,pico,consultorio?"true":"false",leitos,alerta?"true":"false");
}
void setup(){
  Serial.begin(115200); Wire.begin(21,22); lcd.init(); lcd.backlight();
  for(int p : {A,B,CONS,L1,L2}) pinMode(p,INPUT_PULLUP);
  for(int p : {VERDE,AMARELO,VERMELHO}) pinMode(p,OUTPUT);
  anteriorA=digitalRead(A)==LOW; anteriorB=digitalRead(B)==LOW;
  bloqueio=anteriorA||anteriorB;
}
void loop(){
  bool a=digitalRead(A)==LOW,b=digitalRead(B)==LOW;
  bool ea=a&&!anteriorA, eb=b&&!anteriorB;
  anteriorA=a; anteriorB=b;
  bool mudou=false;
  if(primeiro && millis()-inicio>=LIMITE){ primeiro=0; bloqueio=a||b; Serial.println("Passagem incompleta cancelada"); }
  if(bloqueio){ if(!a&&!b) bloqueio=false; }
  else if(ea&&eb){ primeiro=0; bloqueio=true; Serial.println("Passagem ambigua ignorada"); }
  else if(ea||eb){
    int atual=ea?1:2;
    if(!primeiro){ primeiro=atual; inicio=millis(); }
    else if(primeiro==atual){ inicio=millis(); }
    else {
      if(primeiro==1){ presentes++; entradas++; if(presentes>pico) pico=presentes; mudou=true; }
      else if(presentes>0){ presentes--; saidas++; mudou=true; }
      else Serial.println("Saida ignorada: contagem zerada");
      primeiro=0; bloqueio=true;
    }
  }
  bool c=digitalRead(CONS)==LOW, l1=digitalRead(L1)==LOW,l2=digitalRead(L2)==LOW;
  int estado=(c?4:0)+(l1?2:0)+(l2?1:0);
  if(mudou||estado!=ultimoEstado){ ultimoEstado=estado; painel(c,int(l1)+int(l2)); }
  delay(10);
}